package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Controller {
	static final String DB_URL = "jdbc:mysql://localhost:3306/vehicle_db";
	static final String USERNAME = "root";
	static final String PASSWORD = "root";
	String QUERY = "SELECT * FROM vehicle";

	public static void main(String[] args) {
		getAllvehicles(); // Read Operation
		updateVehicleName(1, "Truck"); // Update Operation
		insertRow(2, "Car"); // Create Operation
		deleteVehicle(2); // Delete Operation
	}

	private static void getAllvehicles() {
		String query = "SELECT * FROM vehicle";
		try {
			Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				// Retrieve by column name
				System.out.print("Vehicle ID: " + rs.getInt("vehicleId"));
				System.out.print(" Vehicle Name: " + rs.getString("vehicleName") + "\n");
			}
		} catch (SQLException e) {
			System.out.println("SQL Grammer Exception");
			System.out.println(e);
		}
	}

	private static boolean checkPresence(int vehicleId) {
		boolean flag = false;
		String query = "SELECT * FROM vehicle WHERE vehicleId=?;";
		try {
			Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setInt(1, vehicleId);
			ResultSet rs = stmt.executeQuery();
			if (rs.next())
				flag = true;
		} catch (SQLException e) {
			System.out.println("SQL Grammer Exception");
			System.out.println(e);
		}
		return flag;
	}

	private static void insertRow(int vehicleId, String vehicleName) {
		if (!checkPresence(vehicleId)) {
			String query = "INSERT INTO VEHICLE VALUES(?,?);";
			try {
				Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.setInt(1, vehicleId);
				stmt.setString(2, vehicleName);

				int result = stmt.executeUpdate();
				if (result > 0)
					System.out.println("A new vehicle was inserted Successfully");
			} catch (SQLException e) {
				System.out.println("SQL Grammer Exception");
				System.out.println(e);
			}
		} else {
			System.out.println(
					"A vehicle already exists with vehicleId: " + vehicleId + ". Cannot insert with same vehicle Id");
		}
	}

	private static void updateVehicleName(int vehicleId, String vehicleName) {
		if (checkPresence(vehicleId)) {
			String query = "UPDATE VEHICLE SET vehicleName=? WHERE vehicleId=?;";
			try {
				Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.setString(1, vehicleName);
				stmt.setInt(2, vehicleId);

				int result = stmt.executeUpdate();
				if (result > 0)
					System.out.println("Updated Successfully");
			} catch (SQLException e) {
				System.out.println("SQL Grammer Exception");
				System.out.println(e);
			}
		} else {
			System.out.println("No vehicle exists with vehicleId: " + vehicleId);
		}
	}

	private static void deleteVehicle(int vehicleId) {
		if (checkPresence(vehicleId)) {
			String query = "DELETE FROM VEHICLE WHERE vehicleId=?;";
			try {
				Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.setInt(1, vehicleId);

				int result = stmt.executeUpdate();
				if (result > 0)
					System.out.println("Deleted Successfully");
			} catch (SQLException e) {
				System.out.println("SQL Grammer Exception");
				System.out.println(e);
			}
		} else {
			System.out.println("No vehicle exists with vehicleId: " + vehicleId);
		}
	}

}
